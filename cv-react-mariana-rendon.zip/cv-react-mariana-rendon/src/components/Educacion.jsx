import React from 'react';

const Educacion = () => {
  return (
    <section>
      <h2>Formación Académica</h2>
      <ul>
        <li>
          <strong>Técnico en Programación de Sistemas</strong> – SENA (2024)
        </li>
        <li>
          <strong>Curso de React.js</strong> – Platzi (2025)
        </li>
        <li>
          <strong>Curso de Fundamentos de JavaScript</strong> – FreeCodeCamp (2025)
        </li>
        <li>
          <strong>Taller de Desarrollo Web Front-End</strong> – Comunidad Tech (2025)
        </li>
      </ul>
    </section>
  );
};

export default Educacion;

